import java.io.*;
import java.util.Scanner;

public class DragonWorld {

    public static void main(String[] args) {

        String spielername = SaveAndLoad.loadCharakter()[0];

        System.out.println("Hallo " + spielername);

        starten();

    }

    public static void starten() {

        System.out.println("Möchtest du das Spiel starten oder verlassen?");
        String start = new java.util.Scanner(System.in).next();
        abfrage(0);


        switch (start) {
            case "starten", "Starten", "Start", "start", "START", "Spiel Starten", "Spiel starten", "SPIEL STARTEN", "STARTEN" -> abfrage(1);
            case "VERLASSEN", "verlassen", "Verlassen", "Spiel Verlassen", "SPIEL VERLASSEN", "Spiel verlassen", "spiel verlassen" -> abfrage(2);
            default -> abfrage(3);
        }

    }


    static void abfrage(int eingabe){

        switch(eingabe){
            case 1: //Spiel startet
                Run.run();

            case 2: //Beenden
                System.out.println("Bis zum nächsten Abenteuer!!");
                break;

            case 3: //neue Eingabe
                System.out.println("Ich habe dich nicht verstanden. Bitte gib 'Spiel starten' oder 'Spiel verlassen' ein.");
                starten();
                break;

        }
    }

}