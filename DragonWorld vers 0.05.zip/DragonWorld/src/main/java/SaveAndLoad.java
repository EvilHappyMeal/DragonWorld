import java.io.*;
import java.util.Scanner;

public class SaveAndLoad {

    public static void saveInventory(int henkersschwert, int grossschwert, int morgenstern, int kampfhammer, int kirschen, int tollkirschen, int heilpflanzen, int gold) {

        File saveInventory = new File("saveInventory.txt");
        File folder = new File("DragonWorld");

        if (!saveInventory.exists()) {
            try {
                saveInventory.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (!folder.exists()) {
            //noinspection ResultOfMethodCallIgnored
            folder.mkdirs();
        }

        Integer henkersschwertKonverter = henkersschwert;
        String henkersschwertString = henkersschwertKonverter.toString();
        Integer grossschwertKonverter = grossschwert;
        String grossschwertString = grossschwertKonverter.toString();
        Integer morgensternKonverter = morgenstern;
        String morgensternString = morgensternKonverter.toString();
        Integer kampfhammerKonverter = kampfhammer;
        String kampfhammerString = kampfhammerKonverter.toString();
        Integer kirschenKonverter = kirschen;
        String kirschenString = kirschenKonverter.toString();
        Integer tollkirschenKonverter = tollkirschen;
        String tollkirschenString = tollkirschenKonverter.toString();
        Integer heilpflanzenKonverter = heilpflanzen;
        String heilpflanzenString = heilpflanzenKonverter.toString();
        Integer goldKonverter = gold;
        String goldString = goldKonverter.toString();

        String contentToWrite = henkersschwertString + "\n" + grossschwertString + "\n" + morgensternString + "\n" + kampfhammerString + "\n" + kirschenString + "\n" + tollkirschenString + "\n" + heilpflanzenString + "\n" + goldString;


        try {
            OutputStream stream = new FileOutputStream(saveInventory);
            stream.write(contentToWrite.getBytes());
            stream.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static int[] loadInventary() {

        File saveInventory = new File("saveInventory.txt");

        int[] inventary = {0, 0, 0, 0, 0, 0, 0, 0};

        if (saveInventory.exists()) {
            try {
                Scanner sc = new Scanner(saveInventory);

                int zaehler = 0;

                while (sc.hasNext()) {
                    inventary[zaehler] = sc.nextInt();
                    zaehler++;
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }

        return inventary;

    }

    public static void saveRaum(int raum, int linkerWeg, int mittlererWeg, int rechterWeg, int[] items, int[] gegner) {

        File saveRaum = new File("saveRaum.txt");
        File folder = new File("DragonWorld");

        if (!saveRaum.exists()) {
            try {
                saveRaum.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (!folder.exists()) {
            //noinspection ResultOfMethodCallIgnored
            folder.mkdirs();
        }

        //Array items in ints aufteilen
        int truhe = items[0];
        int pferd = items[1];
        int haendler = items[2];
        int essbarePflanze = items[3];
        int heilpflanze = items[4];
        int giftpflanze = items[5];

        //Array gegner in ints aufteilen
        int wolf = gegner[0];
        int banditen = gegner[1];
        int skelette = gegner[2];
        int riesen = gegner[3];
        int ork = gegner[4];


        Integer raumKonverter = raum;
        String raumString = raumKonverter.toString();
        Integer linkerWegKonverter = linkerWeg;
        String linkerWegString = linkerWegKonverter.toString();
        Integer mittlererWegKonverter = mittlererWeg;
        String mittlererWegString = mittlererWegKonverter.toString();
        Integer rechterWegKonverter = rechterWeg;
        String rechterWegString = rechterWegKonverter.toString();
        Integer truheKonverter = truhe;
        String truheString = truheKonverter.toString();
        Integer pferdKonverter = pferd;
        String pferdString = pferdKonverter.toString();
        Integer haendlerKonverter = haendler;
        String haendlerString = haendlerKonverter.toString();
        Integer essbarePflanzeKonverter = essbarePflanze;
        String essbarePflanzeString = essbarePflanzeKonverter.toString();
        Integer heilpflanzeKonverter = heilpflanze;
        String heilpflanzeString = heilpflanzeKonverter.toString();
        Integer giftpflanzeKonverter = giftpflanze;
        String giftpflanzeString = giftpflanzeKonverter.toString();
        Integer wolfKonverter = wolf;
        String wolfString = wolfKonverter.toString();
        Integer banditenKonverter = banditen;
        String banditenString = banditenKonverter.toString();
        Integer skeletteKonverter = skelette;
        String skeletteString = skeletteKonverter.toString();
        Integer riesenKonverter = riesen;
        String riesenString = riesenKonverter.toString();
        Integer orkKonverter = ork;
        String orkString = orkKonverter.toString();

        String contentToWrite = raumString + "\n" + linkerWegString + "\n" + mittlererWegString + "\n" + rechterWegString + "\n" + truheString + "\n" + pferdString + "\n" + haendlerString + "\n" + essbarePflanzeString + "\n" + heilpflanzeString + "\n" + giftpflanzeString + "\n" + wolfString + "\n" + banditenString + "\n" + skeletteString + "\n" + riesenString + "\n" + orkString;

        try {
            OutputStream stream = new FileOutputStream(saveRaum);
            stream.write(contentToWrite.getBytes());
            stream.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static void saveCharakter(String[] charakter) {

        File saveCharakter = new File("saveCharakter.txt");
        File folder = new File("DragonWorld");

        if (!saveCharakter.exists()) {
            try {
                saveCharakter.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (!folder.exists()) {
            //noinspection ResultOfMethodCallIgnored
            folder.mkdirs();
        }

        String spieler = charakter[0];
        String stamm = charakter[1];
        String eltern = charakter[2];
        String ausbildung = charakter[3];

        String contentToWrite = spieler + "\n" + stamm + "\n" + eltern + "\n" + ausbildung;

        try {
            OutputStream stream = new FileOutputStream(saveCharakter);
            stream.write(contentToWrite.getBytes());
            stream.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static String[] loadCharakter() {

        File saveCharakter = new File("C:\\Users\\kevin\\IdeaProjects\\DragonWorld\\saveCharakter.txt");

        String[] charakterLoad = {"", "", "", ""};                  //Spielername, Stamm, Elternberuf, Ausbildung

        if (saveCharakter.exists()) {
            try {
                Scanner sc = new Scanner(saveCharakter);

                int zaehler = 0;

                while (sc.hasNext()) {

                    charakterLoad[zaehler] = sc.next();
                    zaehler++;

                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }

        return charakterLoad;

    }

}
