import java.io.File;
import java.util.Scanner;

public class Run {

    public static void run() {

        File saveCharakter = new File("C:/Users/kevin/IdeaProjects/DragonWorld/saveCharakter.txt");

        if(!saveCharakter.exists())
            CharErstellung.kreatur();

        int aktuellerRaum = 0;
        int aktuellerRaum1 = 0;
        String aktuellerRaumName = null;
        int[] befehlsabfrage = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};                                     //Linker Weg, mittlerer Weg, rechter Weg, Truhe, Pferd, Haendler, Heilpflanze, Essbare Pflanze, Giftpflanze, Gegner

        aktuellerRaum = RaumErstellen.raumErstellen(aktuellerRaum);
        aktuellerRaumName = RaumErstellen.raumName(aktuellerRaumName, aktuellerRaum);

        System.out.println("Du befindest dich aktuell hier: " + aktuellerRaumName);

        spielende:
        for (int i = 0; i < 1; i++) {


            aktuellerRaum1 = aktuellerRaum;


            //Generiere weitere Möglichkeiten + Wegsperrung:

            int wegsperren = RaumErstellen.wegSperren();           //Generiere Anzahl an Wegsperren (0 Sperren = 1, 1 = 2, 2 = 3)

            int linkerWeg = 0;
            int mittlererWeg = 0;
            int rechterWeg = 0;

            switch (wegsperren) {

                case 1:
                    linkerWeg = RaumErstellen.raumErstellen(aktuellerRaum);

                    mittlererWeg = RaumErstellen.raumErstellen(aktuellerRaum);

                    rechterWeg = RaumErstellen.raumErstellen(aktuellerRaum1);


                case 2:
                    linkerWeg = RaumErstellen.raumErstellen(aktuellerRaum);

                    mittlererWeg = RaumErstellen.raumErstellen(aktuellerRaum);


                case 3:
                    linkerWeg = RaumErstellen.raumErstellen(aktuellerRaum);

            }                               //Generiere linkerWeg, mittlererWeg, rechterWeg

            //Ein Spruch für gesperrte Wege:
            int sperreSpruchWahrscheinlichkeit = (int) (Math.random() * 10);

            String sperreSpruch = switch (sperreSpruchWahrscheinlichkeit) {
                case 0 -> "Oh nein! Der Weg wird durch einen umgefallenen Baum blockiert";
                case 1 -> "Du siehst, dass der Weg über eine marode Brücke führt. Hier kannst du unmöglich entlang!";
                case 2 -> "Der Weg ist durch einen Erdrutch unpassierbar..";
                case 3 -> "Vor dir ist eine tiefe Schlucht, welche du nicht passieren kannst.";
                case 4 -> "Eine große Klippe versperrt dir den Weg.";
                case 5 -> "Hier ist ein See. Du kannst hier nicht lang";
                case 6 -> "Dieser Weg ist wegen Wartungsarbeiten gesperrt.";
                case 7 -> "Du kannst hier nicht entlang";
                case 8 -> "Was eine schöne Blumenwiese hier ist. Du möchtest die Bienen nicht bei der Arbeit stören";
                case 9 -> "Bauern versperren dir den Weg mit ihrem Wagen";
                default -> null;

            }; //Ausgabe für nächste Wege

            switch (linkerWeg) {
                case 0 -> {
                    System.out.println("links " + sperreSpruch);
                    befehlsabfrage[0] = 0;
                }
                case 1 -> {
                    System.out.println("Links geht es in einen düsteren Wald");
                    befehlsabfrage[0] = 1;
                }
                case 2 -> {
                    System.out.println("Links geht es auf eine Wiese");
                    befehlsabfrage[0] = 1;
                }
                case 3 -> {
                    System.out.println("Links geht es in eine karge Wüste");
                    befehlsabfrage[0] = 1;
                }
                case 4 -> {
                    System.out.println("Links geht es in eine herrliche Oase");
                    befehlsabfrage[0] = 1;
                }
                case 5 -> {
                    System.out.println("Links geht es in ein kleines Dorf");
                    befehlsabfrage[0] = 1;
                }
                case 6 -> {
                    System.out.println("Der linke Weg führt dich in eine Stadt");
                    befehlsabfrage[0] = 1;
                }
                case 7 -> {
                    System.out.println("Links geht es auf einen Friedhof");
                    befehlsabfrage[0] = 1;
                }
                case 8 -> {
                    System.out.println("Links geht es in ein Dungeon!");
                    befehlsabfrage[0] = 1;
                }
                case 9 -> {
                    System.out.println("Links geht es auf einen hohen Berg");
                    befehlsabfrage[0] = 1;
                }
            }                                //sout für linken Weg

            switch (mittlererWeg) {
                case 0 -> {
                    System.out.println("mitte " + sperreSpruch);
                    befehlsabfrage[1] = 0;
                }
                case 1 -> {
                    System.out.println("Gerade aus geht es in einen düsteren Wald");
                    befehlsabfrage[1] = 1;
                }
                case 2 -> {
                    System.out.println("Gerade aus geht es auf eine Wiese");
                    befehlsabfrage[1] = 1;
                }
                case 3 -> {
                    System.out.println("Gerade aus geht es in eine karge Wüste");
                    befehlsabfrage[1] = 1;
                }
                case 4 -> {
                    System.out.println("Gerade aus geht es in eine herrliche Oase");
                    befehlsabfrage[1] = 1;
                }
                case 5 -> {
                    System.out.println("Gerade aus geht es in ein kleines Dorf");
                    befehlsabfrage[1] = 1;
                }
                case 6 -> {
                    System.out.println("Gerade aus geht es in eine Stadt");
                    befehlsabfrage[1] = 1;
                }
                case 7 -> {
                    System.out.println("Gerade aus geht es auf einen Friedhof");
                    befehlsabfrage[1] = 1;
                }
                case 8 -> {
                    System.out.println("Gerade aus geht es in ein Dungeon!");
                    befehlsabfrage[1] = 1;
                }
                case 9 -> {
                    System.out.println("Gerade aus geht es auf einen hohen Berg");
                    befehlsabfrage[1] = 1;
                }
            }                             //sout für mittleren Weg

            switch (rechterWeg) {
                case 0 -> {
                    System.out.println("rechts " + sperreSpruch);
                    befehlsabfrage[2] = 0;
                }
                case 1 -> {
                    System.out.println("Rechts geht es in einen düsteren Wald");
                    befehlsabfrage[2] = 1;
                }
                case 2 -> {
                    System.out.println("Rechts geht es auf eine Wiese");
                    befehlsabfrage[2] = 1;
                }
                case 3 -> {
                    System.out.println("Rechts geht es in eine karge Wüste");
                    befehlsabfrage[2] = 1;
                }
                case 4 -> {
                    System.out.println("Rechts geht es in eine herrliche Oase");
                    befehlsabfrage[2] = 1;
                }
                case 5 -> {
                    System.out.println("Rechts geht es in ein kleines Dorf");
                    befehlsabfrage[2] = 1;
                }
                case 6 -> {
                    System.out.println("Der rechte Weg führt dich in eine Stadt");
                    befehlsabfrage[2] = 1;
                }
                case 7 -> {
                    System.out.println("Rechts geht es auf einen Friedhof");
                    befehlsabfrage[2] = 1;
                }
                case 8 -> {
                    System.out.println("Rechts geht es in ein Dungeon!");
                    befehlsabfrage[2] = 1;
                }
                case 9 -> {
                    System.out.println("Rechts geht es auf einen hohen Berg");
                    befehlsabfrage[2] = 1;
                }
            }                               //sout für rechten Weg


            //Truhen, Händler, Pflanzen generieren:
            int truhe = 0;
            int pferd = 0;
            int haendler = 0;
            int essbarePflanze = 0;
            int heilpflanze = 0;
            int giftpflanze = 0;

            switch (aktuellerRaum1) {
                case 1 -> {
                    if ((int) (Math.random() * 100) < 20)
                        truhe = 1;
                    else
                        truhe = 0;
                    if ((int) (Math.random() * 100) < 20)
                        haendler = 1;
                    else
                        haendler = 0;
                    if ((int) (Math.random() * 100) < 20)
                        essbarePflanze = 1;
                    else
                        essbarePflanze = 0;
                    if ((int) (Math.random() * 100) < 20)
                        heilpflanze = 1;
                    else
                        heilpflanze = 0;
                    if ((int) (Math.random() * 100) < 20)
                        giftpflanze = 1;
                    else
                        giftpflanze = 0;
                    break;
                }                       //Wald
                case 2 -> {
                    if ((int) (Math.random() * 100) < 5)
                        haendler = 1;
                    else
                        haendler = 0;
                    if ((int) (Math.random() * 100) < 35)
                        pferd = 1;
                    else
                        pferd = 0;
                    if ((int) (Math.random() * 100) < 20)
                        essbarePflanze = 1;
                    else
                        essbarePflanze = 0;
                    if ((int) (Math.random() * 100) < 20)
                        heilpflanze = 1;
                    else
                        heilpflanze = 0;
                    if ((int) (Math.random() * 100) < 20)
                        giftpflanze = 1;
                    else
                        giftpflanze = 0;
                    break;
                }                       //Wiese
                case 3 -> {
                    if ((int) (Math.random() * 100) < 35)
                        truhe = 1;
                    else
                        truhe = 0;
                    if ((int) (Math.random() * 100) < 15)
                        haendler = 1;
                    else
                        haendler = 0;
                    if ((int) (Math.random() * 100) < 15)
                        pferd = 1;
                    else
                        pferd = 0;
                    break;
                }                       //Wüste
                case 4 -> {
                    if ((int) (Math.random() * 100) < 25)
                        truhe = 1;
                    else
                        truhe = 0;
                    if ((int) (Math.random() * 100) < 25)
                        haendler = 1;
                    else
                        haendler = 0;
                    if ((int) (Math.random() * 100) < 25)
                        essbarePflanze = 1;
                    else
                        essbarePflanze = 0;
                    if ((int) (Math.random() * 100) < 25)
                        heilpflanze = 1;
                    else
                        heilpflanze = 0;
                    break;
                }                       //Oase
                case 5 -> {
                    if ((int) (Math.random() * 100) < 20)
                        truhe = 1;
                    else
                        truhe = 0;
                    if ((int) (Math.random() * 100) < 50)
                        haendler = 1;
                    else
                        haendler = 0;
                    if ((int) (Math.random() * 100) < 15)
                        essbarePflanze = 1;
                    else
                        essbarePflanze = 0;
                    if ((int) (Math.random() * 100) < 15)
                        heilpflanze = 1;
                    else
                        heilpflanze = 0;
                    break;
                }                       //Dorf
                case 6 -> {
                    if ((int) (Math.random() * 100) < 35)
                        truhe = 1;
                    else
                        truhe = 0;
                    if ((int) (Math.random() * 100) < 65)
                        haendler = 1;
                    else
                        haendler = 0;
                    break;
                }                       //Stadt
                case 7 -> {
                    if ((int) (Math.random() * 100) < 25)
                        truhe = 1;
                    else
                        truhe = 0;
                    if ((int) (Math.random() * 100) < 25)
                        essbarePflanze = 1;
                    else
                        essbarePflanze = 0;
                    if ((int) (Math.random() * 100) < 25)
                        heilpflanze = 1;
                    else
                        heilpflanze = 0;
                    if ((int) (Math.random() * 100) < 25)
                        giftpflanze = 1;
                    else
                        giftpflanze = 0;
                    break;
                }                       //Friedhof
                case 8 -> {
                    if ((int) (Math.random() * 100) < 70)
                        truhe = 1;
                    else
                        truhe = 0;
                    if ((int) (Math.random() * 100) < 10)
                        essbarePflanze = 1;
                    else
                        essbarePflanze = 0;
                    if ((int) (Math.random() * 100) < 10)
                        heilpflanze = 1;
                    else
                        heilpflanze = 0;
                    if ((int) (Math.random() * 100) < 10)
                        giftpflanze = 1;
                    else
                        giftpflanze = 0;
                    break;
                }                       //Dungeon
                case 9 -> {
                    if ((int) (Math.random() * 100) < 10)
                        truhe = 1;
                    else
                        truhe = 0;
                    if ((int) (Math.random() * 100) < 20)
                        haendler = 1;
                    else
                        haendler = 0;
                    if ((int) (Math.random() * 100) < 30)
                        essbarePflanze = 1;
                    else
                        essbarePflanze = 0;
                    if ((int) (Math.random() * 100) < 30)
                        heilpflanze = 1;
                    else
                        heilpflanze = 0;
                    if ((int) (Math.random() * 100) < 10)
                        giftpflanze = 1;
                    else
                        giftpflanze = 0;
                    break;
                }                       //Berg
            }

            String truheString;
            String pferdString;
            String haendlerString;
            String essbarePflanzeString;
            String heilpflanzeString;
            String giftpflanzeString;
            int keinItemSpawn = 0;

            if (truhe == 1) {
                truheString = "eine Truhe";
                befehlsabfrage[3] = 1;
                keinItemSpawn = 1;
            } else {
                truheString = "";
                befehlsabfrage[3] = 0;
            }
            if (pferd == 1) {
                pferdString = "ein Pferd";
                befehlsabfrage[4] = 1;
                keinItemSpawn = 1;
            } else {
                pferdString = "";
                befehlsabfrage[4] = 0;
            }
            if (haendler == 1) {
                haendlerString = "einen Händler";
                befehlsabfrage[5] = 1;
                keinItemSpawn = 1;
            } else {
                haendlerString = "";
                befehlsabfrage[5] = 0;
            }
            if (essbarePflanze == 1) {
                essbarePflanzeString = "Kirschen";
                befehlsabfrage[6] = 1;
                keinItemSpawn = 1;
            } else {
                essbarePflanzeString = "";
                befehlsabfrage[6] = 0;
            }
            if (heilpflanze == 1) {
                heilpflanzeString = "eine Heilpflanze";
                befehlsabfrage[7] = 1;
                keinItemSpawn = 1;
            } else {
                heilpflanzeString = "";
                befehlsabfrage[7] = 0;
            }
            if (giftpflanze == 1) {
                giftpflanzeString = "eine Tollkirsche";
                befehlsabfrage[8] = 1;
                keinItemSpawn = 1;
            } else {
                giftpflanzeString = "";
                keinItemSpawn = 1;
                befehlsabfrage[8] = 0;
            }

            if (keinItemSpawn == 0)
                System.out.println("Hier gibt es " + truheString + ", " + pferdString + ", " + haendlerString + ", " + essbarePflanzeString + ", " + heilpflanzeString + " und " + giftpflanzeString);

            int [] items = {truhe, pferd, haendler, essbarePflanze, heilpflanze, giftpflanze};


            //Gegner generieren:

            int skelett = 0;
            int wolf = 0;
            int riese = 0;
            int ork = 0;
            int banditen = 0;
            int gegnerzahl = (int) ((Math.random() * 10) / 2);
            int wahrscheinlichkeitGegner = (int) (Math.random() * 100);
            if (wahrscheinlichkeitGegner < 35)
                gegnerzahl = 0;
            if (gegnerzahl > 0)
                befehlsabfrage[9] = 1;
            else
                befehlsabfrage[9] = 0;

            switch (aktuellerRaum1) {
                case 1 -> {
                    wolf = gegnerzahl;
                    banditen = gegnerzahl;
                }
                case 2 -> {
                    wolf = gegnerzahl / 2;
                    if((int)(Math.random() * 100) > 50)
                    banditen = gegnerzahl;
                    else
                        ork = gegnerzahl;
                }
                case 3 -> {
                    skelett = gegnerzahl;
                    wolf = gegnerzahl;
                    banditen = gegnerzahl;
                }
                case 4 -> {
                    banditen = gegnerzahl;
                    ork = gegnerzahl;
                }
                case 5 -> banditen = gegnerzahl;
                case 6 -> banditen = gegnerzahl / 2;
                case 7 -> skelett = gegnerzahl;
                case 8 -> {
                    skelett = gegnerzahl;
                    wolf = gegnerzahl;
                }
                case 9 -> {
                    riese = gegnerzahl;
                    wolf = gegnerzahl;
                }
            }

            String wolfAnzahl;
            String banditenAnzahl;
            String skeletteAnzahl;
            String riesenAnzahl;
            String orkAnzahl;
            int keinGegnerSpawn;

            if (wolf > 1) {
                wolfAnzahl = (gegnerzahl + " Wölfe");
                keinGegnerSpawn = 0;
            }
            else {
                wolfAnzahl = "";
                keinGegnerSpawn = 1;
            }
            if (banditen > 1) {
                banditenAnzahl = gegnerzahl + " Banditen";
                keinGegnerSpawn = 0;
            }
            else {
                banditenAnzahl = "";
                keinGegnerSpawn = 1;
            }
            if (skelett > 1) {
                skeletteAnzahl = gegnerzahl + " Skelette";
                keinGegnerSpawn = 0;
            }
            else {
                skeletteAnzahl = "";
                keinGegnerSpawn = 1;
            }
            if (riese > 1) {
                riesenAnzahl = gegnerzahl + " Riesen";
                keinGegnerSpawn = 0;
            }
            else {
                riesenAnzahl = "";
                keinGegnerSpawn = 1;
            }
            if (ork > 1) {
                orkAnzahl = gegnerzahl + " Orks";
                keinGegnerSpawn = 0;
            }
            else {
                orkAnzahl = "";
                keinGegnerSpawn = 1;
            }

            int [] gegner = {wolf, banditen, skelett, riese, ork};

            if (keinGegnerSpawn == 0)
                System.out.println("Hier gibt es " + wolfAnzahl + " " + banditenAnzahl + " " + skeletteAnzahl + " " + riesenAnzahl + " " + orkAnzahl);

            System.out.println(wolfAnzahl + orkAnzahl + banditenAnzahl + riesenAnzahl + skeletteAnzahl);

            SaveAndLoad.saveRaum(aktuellerRaum1, linkerWeg, mittlererWeg, rechterWeg, items, gegner);

            //Befehlseingabe:

            System.out.println("Was möchtest du tun? Gib einen der folgenden Befehle ein:");

            String befehlsabfrageLinks = "";
            String befehlsabfrageMitte = "";
            String befehlsabfrageRechts = "";
            String befehlsabfrageTruhe = "";
            String befehlsabfragePferd = "";
            String befehlsabfrageHandel = "";
            String befehlsabfrageHeilpflanze = "";
            String befehlsabfrageEssbarepflanze = "";
            String befehlsabfrageGiftpflanze = "";
            String befehlsabfrageGegner = "";

            if (befehlsabfrage[0] == 1)
                befehlsabfrageLinks = "Nach links gehen";
            else
                befehlsabfrageLinks = "";
            if (befehlsabfrage[1] == 1)
                befehlsabfrageMitte = "Gerade aus gehen";
            else
                befehlsabfrageMitte = "";
            if (befehlsabfrage[2] == 1)
                befehlsabfrageRechts = "Nach rechts gehen";
            else
                befehlsabfrageRechts = "";
            if (befehlsabfrage[3] == 1)
                befehlsabfrageTruhe = "Truhe öffnen";
            else
                befehlsabfrageTruhe = "";
            if (befehlsabfrage[4] == 1)
                befehlsabfragePferd = "Pferd zähmen";
            else
                befehlsabfragePferd = "";
            if (befehlsabfrage[5] == 1)
                befehlsabfrageHandel = "Handeln";
            else
                befehlsabfrageHandel = "";
            if (befehlsabfrage[6] == 1)
                befehlsabfrageHeilpflanze = "Heilpflanze pflücken";
            else
                befehlsabfrageHeilpflanze = "";
            if (befehlsabfrage[7] == 1)
                befehlsabfrageEssbarepflanze = "Kirschen pflücken";
            else
                befehlsabfrageEssbarepflanze = "";
            if (befehlsabfrage[8] == 1)
                befehlsabfrageGiftpflanze = "Tollkirsche pflücken";
            else
                befehlsabfrageGiftpflanze = "";
            if (befehlsabfrage[9] == 1)
                befehlsabfrageGegner = "Gegner Angreifen";
            else
                befehlsabfrageGegner = "";

            System.out.println(befehlsabfrageLinks + " " + befehlsabfrageMitte + " " + befehlsabfrageRechts + " " + befehlsabfragePferd + " " + befehlsabfrageHandel + " " + befehlsabfrageTruhe + " " + befehlsabfrageGiftpflanze + " " + befehlsabfrageEssbarepflanze + " " + befehlsabfrageHeilpflanze + " " + befehlsabfrageGegner);
            System.out.println("Oder tippe 'hilfe' ein, um weitere Befehele gelistet zu bekommen");

            //Speichern

            //Starte Befehlseingabe

            String naechsterSchritt;
            int[] truheInhaltArray;
            String truheInhalt = "";
            int befehlsausgabeLoop = 0;
            int befehlseingabe;

            do {

                befehlseingabe = Befehlseingabe.befehlseingabe();

                switch (befehlseingabe) {

                    case 4:                                                     //Truhe öffnen
                        truheInhaltArray = truheoeffnen();
                        if (truheInhaltArray[0] != 0) {
                            truheInhalt = truheInhalt + truheInhaltArray[0] + " Gold";
                        } else {
                            truheInhalt = truheInhalt + "";
                        }              //Gold
                        if (truheInhaltArray[1] != 0) {
                            truheInhalt = truheInhalt + truheInhaltArray[1] + " Kirschen";
                        } else {
                            truheInhalt = truheInhalt + "";
                        }              //Kirschen
                        if (truheInhaltArray[2] != 0) {
                            truheInhalt = truheInhalt + truheInhaltArray[2] + " Tollkirschen";
                        } else {
                            truheInhalt = truheInhalt + "";
                        }              //Tollkirschen
                        if (truheInhaltArray[3] != 0) {
                            truheInhalt = truheInhalt + truheInhaltArray[3] + " Heilpflanzen";
                        } else {
                            truheInhalt = truheInhalt + "";
                        }              //Heilpflanzen
                        System.out.println("In der Truhe befindet sich " + truheInhalt);
                        break;

                    case 5:                                                     //Pferd zähmen
                        break;
                    case 6:                                                     //Handeln
                        haendler();
                        break;
                    case 7:                                                     //Heilpflanze pflücken
                        Inventar.inventary(6, 1);
                        break;
                    case 8:                                                     //Tollkirsche pflücken
                        Inventar.inventary(5, 1);
                        break;
                    case 9:                                                     //Kirsche pflücken
                        Inventar.inventary(4, 1);
                        break;
                    case 10:                                                    //Gegner angreifen
                        break;
                    case 11:
                        befehlsausgabeLoop = 1;
                        System.out.println("Du gehst weiter.");
                        break;                                                  //Weitergehen
                    case 12:
                        break spielende;
                }

            } while (befehlsausgabeLoop == 0);

            System.out.println();

            //sout"Wohin gehst du?"


        }
        //While LOOOOOP Ende


    }

    public static int[] truheoeffnen() {

        int truhenInhalt[] = {0, 0, 0, 0};                                   //Gold, Kirsche, Tollkirsche, Heilpflanze

        if ((int) (Math.random() * 100) < 50)
            truhenInhalt[0] = (int) (Math.random() * 40);
        if ((int) (Math.random() * 100) < 10) {
            truhenInhalt[0] = (int) (Math.random() * 100);
            if (truhenInhalt[0] < 25)
                truhenInhalt[0] = truhenInhalt[0] + 40;
        }
        if ((int) (Math.random() * 100) < 3) {
            truhenInhalt[0] = (int) (Math.random() * 1000);
            if (truhenInhalt[0] < 300)
                truhenInhalt[0] = truhenInhalt[0] + 500;
        }

        if ((int) (Math.random() * 100) < 25)
            truhenInhalt[1] = (int) (Math.random() * 30);

        if ((int) (Math.random() * 100) < 10)
            truhenInhalt[2] = (int) (Math.random() * 10);

        if ((int) (Math.random() * 100) < 15)
            truhenInhalt[3] = (int) (Math.random() * 20);


        if (truhenInhalt[0] != 0)
            Inventar.inventary(7, truhenInhalt[0]);

        if (truhenInhalt[1] != 0)
            Inventar.inventary(4, truhenInhalt[1]);

        if (truhenInhalt[2] != 0)
            Inventar.inventary(5, truhenInhalt[2]);

        if (truhenInhalt[3] != 0)
            Inventar.inventary(6, truhenInhalt[3]);

        return truhenInhalt;

    }                                   //Spawnt Items in Truhen


    public static int [] haendler(){

        String randomName;
        int randomNameMath = (int)(Math.random() * 100);

        int henkersschwert = 0;
        int grossschwert = 0;
        int morgenstern = 0;
        int kampfhammer = 0;
        int kirschen = 0;
        int heilpflanzen = 0;
        int giftpflanzen = 0;
        int goldHaendler = 100;

        String henkersschwertString;
        String grossschwertString;
        String morgensternString;
        String kampfhammerString;
        String kirschenString;
        String heilpflanzenString;
        String giftpflanzenString;

        int henkersschwertPreis = ((int)(Math.random() * 100) + 100);
        int grossschwertPreis = ((int)(Math.random() * 500) + 1500);
        int morgensternPreis = ((int)(Math.random() * 30) + 230);
        int kampfhammerPreis = ((int)(Math.random() * 500) + 1500);
        int kirschenPreis = (int)(Math.random() * 10);
        int heilpflanzenPreis = (int)(Math.random() * 15);
        int giftpflanzePreis = (int)(Math.random() * 30);

        int henkersschwertMenge = 0;
        int grossschwertMenge = 0;
        int morgensternMenge = 0;
        int kampfhammerMenge = 0;
        int kirschenMenge = 0;
        int giftpflanzenMenge = 0;
        int heilpflanzenMenge = 0;

        if(randomNameMath < 20)
            randomName = "Julius";
        else if(randomNameMath < 40)
            randomName = "Konstantin";
        else if(randomNameMath < 60)
            randomName = "Karl";
        else if (randomNameMath < 80)
            randomName = "Kaspar";
        else
            randomName = "Oskar";

        System.out.println("Hallo! Mein Name ist " + randomName + ". Hier sind meine Waren:");

        if((int)(Math.random() * 100) < 15)
            grossschwert = (int)(Math.random() * 3);
        if((int)(Math.random() * 100) < 30)
            henkersschwert = (int)(Math.random() * 10);
        if((int)(Math.random() * 100) < 30)
            morgenstern = (int)(Math.random() * 10);
        if((int)(Math.random() * 100) < 115)
            kampfhammer = (int)(Math.random() * 3);
        if((int)(Math.random() * 100) < 50)
            kirschen = (int)(Math.random() * 50);
        if((int)(Math.random() * 100) < 40)
            heilpflanzen = (int)(Math.random() * 40);
        if((int)(Math.random() * 100) < 30)
            giftpflanzen = (int)(Math.random() * 20);

        goldHaendler = goldHaendler + ((int)(Math.random() * 1000));

        if (henkersschwert == 1)
            henkersschwertString = "Henkersschwert";
        else  if(henkersschwert == 0)
            henkersschwertString = "";
        else
            henkersschwertString = "Henkersschwerter";

        if(grossschwert == 1)
            grossschwertString = "Großschwert";
        else if (grossschwert == 0)
            grossschwertString = "";
        else
            grossschwertString = "Großschwerter";

        if (morgenstern == 1)
            morgensternString = "Morgenstern";
        else if (morgenstern == 0)
            morgensternString = "";
        else
            morgensternString = "Morgensterne";

        if (kampfhammer == 1)
            kampfhammerString = "Kampfhammer";
        else if (kampfhammer == 0)
            kampfhammerString = "";
        else
            kampfhammerString = "Kampfhämmer";

        if (kirschen == 1)
            kirschenString = "Kirsche";
        else if (kirschen == 0)
            kirschenString = "";
        else
            kirschenString = "Kirschen";

        if (giftpflanzen == 1)
            giftpflanzenString = "Tollkirsche";
        else if (giftpflanzen == 0)
            giftpflanzenString = "";
        else
            giftpflanzenString = "Tollkirschen";

        if (heilpflanzen == 1)
            heilpflanzenString = "Heilpflanze";
        else if (heilpflanzen == 0)
            heilpflanzenString = "";
        else
            heilpflanzenString = "Heilpflanzen";


        System.out.println(henkersschwert + " " + henkersschwertString + " " + kampfhammer + " " + kampfhammerString + " " + morgenstern + " " + morgensternString + " " + kirschen + " " + kirschenString + " " + giftpflanzen + " " + giftpflanzenString + " " + heilpflanzen + " " + heilpflanzenString);
        System.out.println("Möchtest du etwas davon kaufen? Gib einfach das Item ein");
        System.out.println("Oder möchtest du etwas verkaufen? Dann tippe 'Verkaufen' ein");
        System.out.println("Oder tippe 'Verlassen' ein, um den Handel zu verlassen");

        String sc = new Scanner(System.in).next();

        switch (sc){

            case "henkersschwert", "Henkersschwert", "henkerschwert", "Henkerschwert":
                System.out.println("Ein Henkerschwert kostet " + henkersschwertPreis + " Gold. Wieviele möchtest du kaufen?");
                henkersschwertMenge = new Scanner(System.in).nextInt();
                break;
            case "grossschwert", "Grossschwert", "Großschwert", "großschwert":
                System.out.println("Ein Großschwert kostet " + grossschwertPreis + " Gold. Wieviele möchtest du kaufen?");
                break;
            case "morgenstern", "Morgenstern":
                System.out.println("Ein Morgenstern kostet " + morgensternPreis + " Gold. Wieviele möchtest du kaufen?");
                break;
            case "kampfhammer", "Kampfhammer":
                System.out.println("Ein Kampfhammer kostet " + kampfhammerPreis + " Gold. Wieviele möchtest du kaufen?");
                break;
            case  "kirsche", "Kirsche", "kirschen", "Kirschen":
                System.out.println("Eine Kirsche kostet " + kirschenPreis + " Gold. Wieviele möchtest du kaufen?");
                break;
            case "tollkirsche", "Tollkirsche", "tollkirschen", "Tollkirschen":
                System.out.println("Eine Tollkirsche kostet " + giftpflanzePreis + " Gold. Wieviele möchtest du kaufen?");
                break;
            case "heilpflanze", "Heilpflanze", "heilpflanzen", "Heilpflanzen":
                System.out.println("Eine Heilpflanze kostet " + heilpflanzenPreis + " Gold. Wieviele möchtest du kaufen?");
                break;
            case "verkaufen", "Verkaufen":
                break;
            case "verlassen", "Verlassen":
                break;

        }

    }


}