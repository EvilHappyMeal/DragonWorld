import java.io.*;
import java.util.Scanner;

public class Save {

    public static void saveInventory(int henkersschwert, int grossschwert, int morgenstern, int kampfhammer, int kirschen, int tollkirschen, int heilpflanzen, int gold ) {

        File saveInventory = new File("saveInventory.txt");
        File folder = new File("DragonWorld");

        if (!saveInventory.exists()) {
            try {
                saveInventory.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (!folder.exists()) {
            //noinspection ResultOfMethodCallIgnored
            folder.mkdirs();
        }

        Integer henkersschwertKonverter = henkersschwert;
        String henkersschwertString = henkersschwertKonverter.toString();
        Integer grossschwertKonverter = grossschwert;
        String grossschwertString = grossschwertKonverter.toString();
        Integer morgensternKonverter = morgenstern;
        String morgensternString = morgensternKonverter.toString();
        Integer kampfhammerKonverter = kampfhammer;
        String kampfhammerString = kampfhammerKonverter.toString();
        Integer kirschenKonverter = kirschen;
        String kirschenString = kirschenKonverter.toString();
        Integer tollkirschenKonverter = tollkirschen;
        String tollkirschenString = tollkirschenKonverter.toString();
        Integer heilpflanzenKonverter = heilpflanzen;
        String heilpflanzenString = heilpflanzenKonverter.toString();
        Integer goldKonverter = gold;
        String goldString = goldKonverter.toString();

        String contentToWrite = henkersschwertString + "\n" + grossschwertString + "\n" + morgensternString + "\n" + kampfhammerString + "\n" + kirschenString + "\n" + tollkirschenString + "\n" + heilpflanzenString + "\n" + goldString;



        try {
            OutputStream stream = new FileOutputStream(saveInventory);
            stream.write(contentToWrite.getBytes());
            stream.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}
