import java.sql.Savepoint;

public class Inventar {

    public static int [] waffen(int waffentyp) {                                     //Waffenliste

        int aktuellerwaffentyp = 0;
        aktuellerwaffentyp = waffentyp;
        int faust;
        int henkerschwert;
        int grossschwert;
        int morgenstern;
        int kampfhammer;
//        int recurvebogen;
//        int langbogen;
        int waffenstaerke [] = {0,0,0};                                         //Schneiden, Zertrümmern, Blocken

        switch (aktuellerwaffentyp) {

            case 0:                                                             //Fäuste
                waffenstaerke [0] = 0;
                waffenstaerke [1] = 10;
                waffenstaerke [2] = 5;
                break;

            case 1:                                                             //Henkerschwert
                waffenstaerke [0] = 25;
                waffenstaerke [1] = 10;
                waffenstaerke [2] = 15;
                break;

            case 2:                                                             //Großschwert
                waffenstaerke [0] = 50;
                waffenstaerke [1] = 10;
                waffenstaerke [2] = 25;
                break;

            case 3:                                                             //Morgenstern
                waffenstaerke [0] = 5;
                waffenstaerke [1] = 25;
                waffenstaerke [2] = 15;
                break;

            case 4:                                                             //Kampfhammer
                waffenstaerke [0] =  5;
                waffenstaerke [1] = 50;
                waffenstaerke [2] = 25;
            break;

//            case 5:                                                             //Recurvebogen
//
//                break;
//
//            case 6:                                                             //Langbogen
//
//                break;

            default:                                                              //default = Fäuste
                aktuellerwaffentyp = 0;
                break;

        }                                       //Schneiden , Zertrümmern, Blocken

        return waffenstaerke;

    }                       //Definieren der verschiedenen Waffentypen

    public static int inventary(int position, int positionMenge){

        //Waffen:
        int henkerschwert = 0;
        int grossschwert = 0;
        int morgenstern = 0;
        int kampfhammer = 0;

        //Pflanzen
        int kirschen = 0;
        int tollkirschen = 0;
        int heilpflanzen = 0;

        //Geld:
        int gold = 0;

        switch (position){

            case 0:
                henkerschwert = henkerschwert + positionMenge;
                break;
            case 1:
                grossschwert = grossschwert + positionMenge;
                break;
            case 2:
                morgenstern = morgenstern + positionMenge;
                break;
            case 3:
                kampfhammer = kampfhammer + positionMenge;
                break;
            case 4:
                kirschen = kirschen + positionMenge;
                break;
            case 5:
                tollkirschen = tollkirschen + positionMenge;
                break;
            case 6:
                heilpflanzen = heilpflanzen + positionMenge;
                break;
            case 7:
                gold = gold + positionMenge;
                break;
            default:
                break;

        }

        Save.saveInventory(henkerschwert, grossschwert, morgenstern, kampfhammer,kirschen,tollkirschen,heilpflanzen,gold);


        int [] inventary = {henkerschwert, grossschwert, morgenstern, kampfhammer, kirschen, tollkirschen, heilpflanzen, gold};

        return inventary [position];

    }

}