public class CharErstellung {
    public static void kreatur() {

        String stamm = null;
        String eltern = null;
        String ausbildung = null;


        System.out.printf("Welchem Stamm gehörst du an?%n Mensch, Ork%n");
        boolean booleanStamm = true;
        while (booleanStamm) {
            String stammA = new java.util.Scanner(System.in).nextLine();
            if (stammA.equals("Mensch") || stammA.equals("mensch")) {
                stamm = "Mensch";
                booleanStamm = false;
            }
            else if (stammA.equals("Ork") || stammA.equals("ork")) {
                stamm = "Ork";
                booleanStamm = false;
            }
            else {
                System.out.println("Ich habe dich nicht verstanden..");
                booleanStamm = true;
            }
        }
        System.out.println("Okay, du bist also ein " + stamm);


        System.out.printf("Deine Eltern waren...%n Krieger, Wirt, Händler, Adelig%n");
        boolean booleanEltern = true;
        while(booleanEltern) {
            String elternA = new java.util.Scanner(System.in).nextLine(); //Eltern
            if (elternA.equals("krieger") || elternA.equals("Krieger")) {
                eltern = "Krieger";
                booleanEltern = false;
            }
            else if (elternA.equals("Wirt") || elternA.equals("wirt")) {
                eltern = "Wirt";
                booleanEltern = false;
            }
            else if (elternA.equals("Schmied") || elternA.equals("schmied")) {
                eltern = "Schmied";
                booleanEltern = false;
            }
            else if (elternA.equals("Kaufmann") || elternA.equals("kaufmann")) {
                eltern = "Kaufmann";
                booleanEltern = false;
            }
            else if (elternA.equals("Adelig") || elternA.equals("adelig")) {
                eltern = "Adelig";
                booleanEltern = false;
            }
            else if (elternA.equals("Händler") || elternA.equals("händler")) {
                eltern = "Händler";
                booleanEltern = false;
            }
            else {
                System.out.println("Ich habe dich nicht verstanden..");
                booleanEltern = true;
            }

        }
        System.out.println("Alles klar, deine Eltern waren " + eltern + "!!");


        System.out.printf("Und welche Ausbildung hast du genossen?%nSchmied, Wirt, Kaufmann, Krieger%n");
        boolean booleanAusbildung = true;
        while(booleanAusbildung) {
            String ausbildungA = new java.util.Scanner(System.in).nextLine();
            if (ausbildungA.equals("schmied") || ausbildungA.equals("Schmied")) {
                ausbildung = "Schmied";
                booleanAusbildung = false;
            } else if (ausbildungA.equals("Wirt") || ausbildungA.equals("wirt")) {
                ausbildung = "Wirt";
                booleanAusbildung = false;

            } else if (ausbildungA.equals("kaufmann") || ausbildungA.equals("Kaufmann")) {
                ausbildung = "Kaufmann";
                booleanAusbildung = false;

            } else if (ausbildungA.equals("Krieger") || ausbildungA.equals("kreiger")) {
                ausbildung = "Krieger";
                booleanAusbildung = false;

            } else {
                System.out.println("Ich habe dich nicht verstanden..");
                booleanAusbildung = true;
            }
        }

        System.out.println("Wow, die Ausbildung zum " + ausbildung + " war bestimmt hart.");
        System.out.println("");
        System.out.println("Du bist also ein " + stamm + ". Deine Eltern waren " + eltern + ". Mit 16 Jahren, beginnst du eine Ausbildung zum " + ausbildung + " und beendest sie erfolgreich");
        System.out.println("");
        System.out.println("Mit 21 Jahren entscheidest du dich, in die Welt zu reisen. Mach dich bereit für dein Abenteuer!");

        Run.run();
    }



//                      Spieldaten speichern:
//
//
//    public static void playerStory(String stamm, String eltern, String ausbildung, String spielername) {
//
//        //Übergabe an Save.txt
//
//
//        File Save1 = new File("C:\\Users\\kevin\\IdeaProjects\\DragonWorld\\Save.txt");
//
//        List<String> lines = Arrays.asList(stamm, eltern, ausbildung);
//        Path pathToWrite = Paths.get(String.valueOf(Save1));
//        try {
//            Files.write(pathToWrite, lines);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }


}
