import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;

public class Run {

    public static void run() {

        File save = new File("Save.txt");
        File folder = new File("DragonWorld");

//        Laden:
//        try {
//            Files.lines(Path.of("Save.txt")).forEach(System.out::println);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

        int aktuellerRaum = 0;
        int aktuellerRaum1 = 0;
        String aktuellerRaumName = null;

        aktuellerRaum = RaumErstellen.raumErstellen(aktuellerRaum);
        aktuellerRaumName = RaumErstellen.raumName(aktuellerRaumName, aktuellerRaum);

        System.out.println("Du befindest dich aktuell hier: " + aktuellerRaumName);


        int wahrscheinlichkeit = (int) (Math.random() * 100);


        for (int i = 0; i < 1 ; i++) {


            aktuellerRaum = aktuellerRaum1;

            //Generiere weitere Möglichkeiten + Wegsperrung

            int wegsperren = RaumErstellen.wegSperren();           //Generiere Anzahl an Wegsperren (0 Sperren = 1, 1 = 2, 2 = 3)

            int linkerWeg = 0;
            int mittlererWeg = 0;
            int rechterWeg = 0;

            switch (wegsperren){

                case 1:
                    linkerWeg = RaumErstellen.raumErstellen(aktuellerRaum);

                    mittlererWeg = RaumErstellen.raumErstellen(aktuellerRaum);

                    rechterWeg = RaumErstellen.raumErstellen(aktuellerRaum);


                case 2:
                    linkerWeg = RaumErstellen.raumErstellen(aktuellerRaum);

                    mittlererWeg = RaumErstellen.raumErstellen(aktuellerRaum);


                case 3:
                    linkerWeg = RaumErstellen.raumErstellen(aktuellerRaum);

            }                               //Generiere linkerWeg, mittlererWeg, rechterWeg

            int sperreSpruchWahrscheinlichkeit = (int) (Math.random() * 10);
            String sperreSpruch = null;

            //Ausgabe für weitere Wege
            switch (sperreSpruchWahrscheinlichkeit){
                case 0:
                    sperreSpruch = "Oh nein! Der Weg wird durch einen umgefallenen Baum blockiert";
                    break;
                case 1:
                    sperreSpruch = "Du siehst, dass der Weg über eine marode Brücke führt. Hier kannst du unmöglich entlang!";
                    break;
                case 2:
                    sperreSpruch = "Der Weg ist durch einen Erdrutch unpassierbar..";
                    break;
                case 3:
                    sperreSpruch = "Vor dir ist eine tiefe Schlucht, welche du nicht passieren kannst.";
                    break;
                case 4:
                    sperreSpruch = "Eine große Klippe versperrt dir den Weg.";
                    break;
                case 5:
                    sperreSpruch = "Hier ist ein See. Du kannst hier nicht lang";
                    break;
                case 6:
                    sperreSpruch = "Dieser Weg ist wegen Wartungsarbeiten gesperrt.";
                    break;
                case 7:
                    sperreSpruch = "Du kannst hier nicht entlang";
                    break;
                case 8:
                    sperreSpruch = "Was eine schöne Blumenwiese hier ist. Du möchtest die Bienen nicht bei der Arbeit stören";
                    break;
                case 9:
                    sperreSpruch = "Bauern versperren dir den Weg mit ihrem Wagen";
                    break;
            }           //Ein Spruch für gesperrte Wege

            switch (linkerWeg){
                case 0:
                    System.out.println("links" + sperreSpruch);
                    break;
                case 1:
                    System.out.println("Links geht es in einen düsteren Wald");
                    break;
                case 2:
                    System.out.println("Links geht es auf eine Wiese");
                    break;
                case 3:
                    System.out.println("Links geht es in eine karge Wüste");
                    break;
                case 4:
                    System.out.println("Links geht es in eine herrliche Oase");
                    break;
                case 5:
                    System.out.println("Links geht es in ein kleines Dorf");
                    break;
                case 6:
                    System.out.println("Der linke Weg führt dich in eine Stadt");
                    break;
                case 7:
                    System.out.println("Links geht es auf einen Friedhof");
                    break;
                case 8:
                    System.out.println("Links geht es in ein Dungeon!");
                    break;
                case 9:
                    System.out.println("Links geht es auf einen hohen Berg");
                    break;
            }                                //sout für linken Weg

            switch (mittlererWeg){
                case 0:
                    System.out.println("mitte" + sperreSpruch);
                    break;
                case 1:
                    System.out.println("Gerade aus geht es in einen düsteren Wald");
                    break;
                case 2:
                    System.out.println("Gerade aus geht es auf eine Wiese");
                    break;
                case 3:
                    System.out.println("Gerade aus geht es in eine karge Wüste");
                    break;
                case 4:
                    System.out.println("Gerade aus geht es in eine herrliche Oase");
                    break;
                case 5:
                    System.out.println("Gerade aus geht es in ein kleines Dorf");
                    break;
                case 6:
                    System.out.println("Gerade aus geht es in eine Stadt");
                    break;
                case 7:
                    System.out.println("Gerade aus geht es auf einen Friedhof");
                    break;
                case 8:
                    System.out.println("Gerade aus geht es in ein Dungeon!");
                    break;
                case 9:
                    System.out.println("Gerade aus geht es auf einen hohen Berg");
                    break;

            }                             //sout für mittleren Weg

            switch (rechterWeg){
                case 0:
                    System.out.println("rechts " + sperreSpruch);
                    break;
                case 1:
                    System.out.println("Rechts geht es in einen düsteren Wald");
                    break;
                case 2:
                    System.out.println("Rechts geht es auf eine Wiese");
                    break;
                case 3:
                    System.out.println("Rechts geht es in eine karge Wüste");
                    break;
                case 4:
                    System.out.println("Rechts geht es in eine herrliche Oase");
                    break;
                case 5:
                    System.out.println("Rechts geht es in ein kleines Dorf");
                    break;
                case 6:
                    System.out.println("Der rechte Weg führt dich in eine Stadt");
                    break;
                case 7:
                    System.out.println("Rechts geht es auf einen Friedhof");
                    break;
                case 8:
                    System.out.println("Rechts geht es in ein Dungeon!");
                    break;
                case 9:
                    System.out.println("Rechts geht es auf einen hohen Berg");
                    break;

            }                               //sout für rechten Weg

            //Hier ist das und das.
            //Es befindet sich mob xyz hier.
            //Was möchtest du tun?"

            //Speichern

            //Starte Befehlseingabe

            //sout was passiert ist

            //sout"Wohin gehst du?"


        }
        //While LOOOOOP Ende



    }

}