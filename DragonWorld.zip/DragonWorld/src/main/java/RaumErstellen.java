public class RaumErstellen {

    public static int raumErstellen(int raumtyp){

        int wahrscheinlichkeit = (int) (Math.random() * 100);

        // 0 = Erster Raum, 1 = Wald, 2 = Wiese, 3 = Wüste, 4 = Oase
        // 5 = Dorf, 6 = Stadt, 7 = Friedhof, 8 = Dungeon, 9 = Berge

        switch (raumtyp) {
                case 0:
                    if (wahrscheinlichkeit < 50)
                        raumtyp = 6;
                    else
                        raumtyp = 5;
                case 1:
                    if (wahrscheinlichkeit < 25)
                        raumtyp = 1;
                    else if (wahrscheinlichkeit < 45)
                        raumtyp = 2;
                    else if (wahrscheinlichkeit < 65)
                        raumtyp = 5;
                    else if (wahrscheinlichkeit < 75)
                        raumtyp = 6;
                    else if (wahrscheinlichkeit < 80)
                        raumtyp = 7;
                    else if (wahrscheinlichkeit < 85)
                        raumtyp = 8;
                    else
                        raumtyp = 9;
                case 2:
                    if (wahrscheinlichkeit < 20)
                        raumtyp = 1;
                    else if (wahrscheinlichkeit < 45)
                        raumtyp = 2;
                    else if (wahrscheinlichkeit < 55)
                        raumtyp = 3;
                    else if (wahrscheinlichkeit < 70)
                        raumtyp = 5;
                    else if (wahrscheinlichkeit < 80)
                        raumtyp = 6;
                    else if (wahrscheinlichkeit < 85)
                        raumtyp = 7;
                    else if (wahrscheinlichkeit < 90)
                        raumtyp = 8;
                    else
                        raumtyp = 9;
                case 3:
                    if (wahrscheinlichkeit < 10)
                        raumtyp = 2;
                    else if (wahrscheinlichkeit < 45)
                        raumtyp = 3;
                    else if (wahrscheinlichkeit < 70)
                        raumtyp = 4;
                    else if (wahrscheinlichkeit < 80)
                        raumtyp = 5;
                    else if (wahrscheinlichkeit < 90)
                        raumtyp = 6;
                    else if (wahrscheinlichkeit < 95)
                        raumtyp = 8;
                    else
                        raumtyp = 9;
                case 4:
                    if (wahrscheinlichkeit < 50)
                        raumtyp = 3;
                    else if (wahrscheinlichkeit < 95)
                        raumtyp = 5;
                    else
                        raumtyp = 8;
                case 5:
                    if (wahrscheinlichkeit < 20)
                        raumtyp = 1;
                    else if (wahrscheinlichkeit < 40)
                        raumtyp = 2;
                    else if (wahrscheinlichkeit < 50)
                        raumtyp = 3;
                    else if (wahrscheinlichkeit < 85)
                        raumtyp = 5;
                    else if (wahrscheinlichkeit < 95)
                        raumtyp = 7;
                    else
                        raumtyp = 8;
                case 6:
                    if (wahrscheinlichkeit < 10)
                        raumtyp = 1;
                    else if (wahrscheinlichkeit < 25)
                        raumtyp = 2;
                    else if (wahrscheinlichkeit < 35)
                        raumtyp = 3;
                    else if (wahrscheinlichkeit < 80)
                        raumtyp = 6;
                    else if (wahrscheinlichkeit < 95)
                        raumtyp = 7;
                    else
                        raumtyp = 8;
                case 7:
                    if (wahrscheinlichkeit < 5)
                        raumtyp = 1;
                    else if (wahrscheinlichkeit < 10)
                        raumtyp = 2;
                    else if (wahrscheinlichkeit < 25)
                        raumtyp = 5;
                    else if (wahrscheinlichkeit < 40)
                        raumtyp = 6;
                    else if (wahrscheinlichkeit < 75)
                        raumtyp = 7;
                    else if (wahrscheinlichkeit < 95)
                        raumtyp = 8;
                    else
                        raumtyp = 9;
                case 8:
                    if (wahrscheinlichkeit < 5)
                        raumtyp = 1;
                    else if (wahrscheinlichkeit < 10)
                        raumtyp = 2;
                    else if (wahrscheinlichkeit < 15)
                        raumtyp = 3;
                    else if (wahrscheinlichkeit < 20)
                        raumtyp = 4;
                    else if (wahrscheinlichkeit < 25)
                        raumtyp = 5;
                    else if (wahrscheinlichkeit < 30)
                        raumtyp = 6;
                    else if (wahrscheinlichkeit < 50)
                        raumtyp = 7;
                    else if (wahrscheinlichkeit < 95)
                        raumtyp = 8;
                    else
                        raumtyp = 9;
                case 9:
                    if (wahrscheinlichkeit < 10)
                        raumtyp = 1;
                    else if (wahrscheinlichkeit < 20)
                        raumtyp = 2;
                    else if (wahrscheinlichkeit < 25)
                        raumtyp = 3;
                    else if (wahrscheinlichkeit < 40)
                        raumtyp = 5;
                    else if (wahrscheinlichkeit < 50)
                        raumtyp = 6;
                    else if (wahrscheinlichkeit < 65)
                        raumtyp = 8;
                    else
                        raumtyp = 9;

        }

        return raumtyp;

    }

    public static String raumName(String raumName, int aktuellerRaum){


        switch (aktuellerRaum){
            case 1:
                raumName = "Wald";
            case 2:
                raumName = "Wiese";
            case 3:
                raumName = "Wüste";
            case 4:
                raumName = "Oase";
            case 5:
                raumName = "Dorf";
            case 6:
                raumName = "Stadt";
            case 7:
                raumName = "Friedhof";
            case 8:
                raumName = "Dungeon";
            case 9:
                raumName = "Berg";
        }

        return raumName;

    }



    public static int wegSperren(){

        int wegsperren = 0;

        int wahrscheinlichkeit1 = (int) (Math.random() * 100);

        if (wahrscheinlichkeit1 < 20)                           // 2 Sperren
            wegsperren = 3;
        else if (wahrscheinlichkeit1 < 40)                      // 1 Sperre
            wegsperren = 2;
        else                                                    // 0 Sperren
            wegsperren = 1;

        return wegsperren;

    }

}
