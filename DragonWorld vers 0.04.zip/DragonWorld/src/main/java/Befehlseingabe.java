public class Befehlseingabe {

    public static int befehlseingabe(){

        String eingabe = new java.util.Scanner(System.in).nextLine();

        boolean eingabeLoop = true;
        int eingabeInt = 0;

        do {

            switch (eingabe) {
                case "hilfe", "Hilfe" -> {
                    eingabeLoop = false;
                    System.out.printf("'Was ist in meinem Inventar?' -> Zeigt den Inhalt deines Inventars /r/n 'Wo befinde ich mich?' -> Wo du dich aktuell befindest");
                    eingabeLoop = true;
                }
                case "Truhe öffnen", "truhe öffnen", "Truhe Öffnen", "TRUHE ÖFFNEN" -> {
                    eingabeInt = 4;
                    eingabeLoop = false;
                }
                case "pferd zähmen", "Pferd Zähmen", "Pferd zähmen", "PFERD ZÄHMEN" -> {
                    eingabeInt = 5;
                    eingabeLoop = false;
                }
                case "handeln", "Handeln", "HANDELN" -> {
                    eingabeInt = 6;
                    eingabeLoop = false;
                }
                case "Heilpflanze pflücken", "Heilpflanze Pflücken", "HEILPFLANZE PFLÜCKEN" -> {
                    eingabeInt = 7;
                    eingabeLoop = false;
                }
                case "Tollkirsche pflücken", "Tollkirsche Pflücken", "TOLLKIRSCHE PFLÜCKEN" -> {
                    eingabeInt = 8;
                    eingabeLoop = false;
                }
                case "Kirsche Pflücken", "Kirsche pflücken", "Kirschen Pflücken", "Kirschen pflücken", "KIRSCHEN PFLÜCKEN", "KIRSCHE PFLÜCKEN" -> {
                    eingabeInt = 9;
                    eingabeLoop = false;
                }
                case "Gegner angreifen", "Gegner Angreifen", "GEGNER ANGREIFEN", "Angreifen", "angreifen", "ANGREIFEN" -> {
                    eingabeInt = 10;
                    eingabeLoop = false;
                }
                case "weitergehen", "Weiter gehen", "Weiter Gehen", "WEITER GEHEN", "WEITERGEHEN", "Weitergehen" -> {
                    eingabeLoop = false;
                    eingabeInt = 11;
                }
                    case "exit", "Exit", "beenden", "Beenden" -> {
                        eingabeInt = 12;
                        eingabeLoop = false;
                }
            }

        }while (eingabeLoop);

        return eingabeInt;

    }

//    case "Nach links gehen", "nach links gehen", "Nach Links gehen", "NACH LINKS GEHEN" -> {
//        eingabeInt = 1;
//        eingabeLoop = false;
//    }
//                case "Nach rechts gehen", "nach rechts gehen", "Nach Rechts gehen", "NACH RECHTS GEHEN" -> {
//        eingabeInt = 3;
//        eingabeLoop = false;
//    }
//                case "Gerade aus gehen", "Gerade Aus Gehen", "gerade aus gehen", "GERADE AUS GEHEN", "geradeaus gehen" -> {
//        eingabeInt = 2;
//        eingabeLoop = false;
//    }

}