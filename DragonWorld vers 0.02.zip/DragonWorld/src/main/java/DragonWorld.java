import java.io.*;
import java.util.Scanner;

public class DragonWorld {

    public static void main(String[] args) {

        File folder1 = new File("DragonWorld");
        File Save1 = new File("Save.txt");
        File Befehle = new File("Befehle.txt");

        String spielername;

        try {
            Scanner sc = new Scanner(Save1);
            spielername = sc.next();

        }                                       // Lade Spielernamen
        catch (FileNotFoundException a) {

            System.out.println("Bitte Spielername eingeben:");
            spielername = new java.util.Scanner(System.in).next();

            if (!Befehle.exists()) {
                try {
                    Befehle.createNewFile();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (!folder1.exists()) {
                //noinspection ResultOfMethodCallIgnored
                folder1.mkdirs();
            }
            if (!Save1.exists()) {
                try {
                    //noinspection ResultOfMethodCallIgnored
                    Save1.createNewFile();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            try {
                OutputStream stream = new FileOutputStream(Save1);
                stream.write(spielername.getBytes());
                stream.close();

            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                Scanner sc = new Scanner(Save1);
                while (sc.hasNext()) {
                    spielername = sc.next();
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }           // Falls Spielername oder Savegame nicht vorhanden sind

        System.out.println("Hallo " + spielername);

        starten();

    }

    public static void starten() {

        System.out.println("Möchtest du das Spiel starten oder verlassen?");
        String start = new java.util.Scanner(System.in).next();
        abfrage(0);


        switch (start) {
            case "starten", "Starten", "Start", "start", "START", "Spiel Starten", "Spiel starten", "SPIEL STARTEN", "STARTEN" -> abfrage(1);
            case "VERLASSEN", "verlassen", "Verlassen", "Spiel Verlassen", "SPIEL VERLASSEN", "Spiel verlassen", "spiel verlassen" -> abfrage(2);
            default -> abfrage(3);
        }

    }


    static void abfrage(int eingabe){

        switch(eingabe){
            case 1: //Spiel startet
                CharErstellung.kreatur();
                Run.run();

            case 2: //Beenden
                System.out.println("Bis zum nächsten Abenteuer!!");
                break;

            case 3: //neue Eingabe
                System.out.println("Ich habe dich nicht verstanden. Bitte gib 'Spiel starten' oder 'Spiel verlassen' ein.");
                starten();
                break;

        }
    }

}
