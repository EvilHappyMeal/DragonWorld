public class Befehlseingabe {

    public static String befehlseingabe(){

        String eingabe = new java.util.Scanner(System.in).nextLine();

        boolean eingabeLoop = true;

        do {
            switch (eingabe) {

                case "hilfe", "Hilfe":
                    eingabeLoop = false;
                    System.out.printf("'Was ist in meinem Inventar?' -> Zeigt den Inhalt deines Inventars/r/n'Wo befinde ich mich?' -> Wo du dich aktuell befindest");
                    eingabeLoop = true;
                    break;
                case "Nach links gehen", "nach links gehen", "Nach Links gehen":

                default:
                    System.out.println("Ich habe dich nicht verstanden. Bitte Eingabe wiederholen!");
                    eingabeLoop = true;

            }
        }while (eingabeLoop == true);

    }

}