import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;

public class Run {

    public static void run() {

        File saveStats = new File("saveStats.txt");
        File saveCharakter = new File("Charakter.txt");
        File folder = new File("DragonWorld");

//                      Laden:
//        try {
//            Files.lines(Path.of("Save.txt")).forEach(System.out::println);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

        int aktuellerRaum = 0;
        int aktuellerRaum1 = 0;
        String aktuellerRaumName = null;
        int [] befehlsabfrage = {0,0,0,0,0,0,0,0,0,0};                                     //Linker Weg, mittlerer Weg, rechter Weg, Truhe, Pferd, Haendler, Heilpflanze, Essbare Pflanze, Giftpflanze, Gegner

        aktuellerRaum = RaumErstellen.raumErstellen(aktuellerRaum);
        aktuellerRaumName = RaumErstellen.raumName(aktuellerRaumName, aktuellerRaum);

        System.out.println("Du befindest dich aktuell hier: " + aktuellerRaumName);


        for (int i = 0; i < 1 ; i++) {


            aktuellerRaum1 = aktuellerRaum;


            //Generiere weitere Möglichkeiten + Wegsperrung:

            int wegsperren = RaumErstellen.wegSperren();           //Generiere Anzahl an Wegsperren (0 Sperren = 1, 1 = 2, 2 = 3)

            int linkerWeg = 0;
            int mittlererWeg = 0;
            int rechterWeg = 0;

            switch (wegsperren){

                case 1:
                    linkerWeg = RaumErstellen.raumErstellen(aktuellerRaum);

                    mittlererWeg = RaumErstellen.raumErstellen(aktuellerRaum);

                    rechterWeg = RaumErstellen.raumErstellen(aktuellerRaum1);


                case 2:
                    linkerWeg = RaumErstellen.raumErstellen(aktuellerRaum);

                    mittlererWeg = RaumErstellen.raumErstellen(aktuellerRaum);


                case 3:
                    linkerWeg = RaumErstellen.raumErstellen(aktuellerRaum);

            }                               //Generiere linkerWeg, mittlererWeg, rechterWeg

            //Ein Spruch für gesperrte Wege:
            int sperreSpruchWahrscheinlichkeit = (int) (Math.random() * 10);

            String sperreSpruch = switch (sperreSpruchWahrscheinlichkeit) {
                case 0 -> "Oh nein! Der Weg wird durch einen umgefallenen Baum blockiert";
                case 1 -> "Du siehst, dass der Weg über eine marode Brücke führt. Hier kannst du unmöglich entlang!";
                case 2 -> "Der Weg ist durch einen Erdrutch unpassierbar..";
                case 3 -> "Vor dir ist eine tiefe Schlucht, welche du nicht passieren kannst.";
                case 4 -> "Eine große Klippe versperrt dir den Weg.";
                case 5 -> "Hier ist ein See. Du kannst hier nicht lang";
                case 6 -> "Dieser Weg ist wegen Wartungsarbeiten gesperrt.";
                case 7 -> "Du kannst hier nicht entlang";
                case 8 -> "Was eine schöne Blumenwiese hier ist. Du möchtest die Bienen nicht bei der Arbeit stören";
                case 9 -> "Bauern versperren dir den Weg mit ihrem Wagen";
                default -> null;

                //Ausgabe für weitere Wege
            };

            switch (linkerWeg) {
                case 0 -> {
                    System.out.println("links " + sperreSpruch);
                    befehlsabfrage [0] = 0;
                }
                case 1 -> {
                    System.out.println("Links geht es in einen düsteren Wald");
                    befehlsabfrage [0] = 1;
                }
                case 2 -> {
                    System.out.println("Links geht es auf eine Wiese");
                    befehlsabfrage [0] = 1;
                }
                case 3 -> {
                    System.out.println("Links geht es in eine karge Wüste");
                    befehlsabfrage [0] = 1;
                }
                case 4 -> {
                    System.out.println("Links geht es in eine herrliche Oase");
                    befehlsabfrage [0] = 1;
                }
                case 5 -> {
                    System.out.println("Links geht es in ein kleines Dorf");
                    befehlsabfrage [0] = 1;
                }
                case 6 -> {
                    System.out.println("Der linke Weg führt dich in eine Stadt");
                    befehlsabfrage [0] = 1;
                }
                case 7 -> {
                    System.out.println("Links geht es auf einen Friedhof");
                    befehlsabfrage [0] = 1;
                }
                case 8 -> {
                    System.out.println("Links geht es in ein Dungeon!");
                    befehlsabfrage [0] = 1;
                }
                case 9 -> {
                    System.out.println("Links geht es auf einen hohen Berg");
                    befehlsabfrage [0] = 1;
                }
            }                                //sout für linken Weg

            switch (mittlererWeg) {
                case 0 -> {
                    System.out.println("mitte " + sperreSpruch);
                    befehlsabfrage [1] = 0;
                }
                case 1 -> {
                    System.out.println("Gerade aus geht es in einen düsteren Wald");
                    befehlsabfrage [1] = 1;
                }
                case 2 -> {
                    System.out.println("Gerade aus geht es auf eine Wiese");
                    befehlsabfrage [1] = 1;
                }
                case 3 -> {
                    System.out.println("Gerade aus geht es in eine karge Wüste");
                    befehlsabfrage [1] = 1;
                }
                case 4 -> {
                    System.out.println("Gerade aus geht es in eine herrliche Oase");
                    befehlsabfrage [1] = 1;
                }
                case 5 -> {
                    System.out.println("Gerade aus geht es in ein kleines Dorf");
                    befehlsabfrage [1] = 1;
                }
                case 6 -> {
                    System.out.println("Gerade aus geht es in eine Stadt");
                    befehlsabfrage [1] = 1;
                }
                case 7 -> {
                    System.out.println("Gerade aus geht es auf einen Friedhof");
                    befehlsabfrage [1] = 1;
                }
                case 8 -> {
                    System.out.println("Gerade aus geht es in ein Dungeon!");
                    befehlsabfrage [1] = 1;
                }
                case 9 -> {
                    System.out.println("Gerade aus geht es auf einen hohen Berg");
                    befehlsabfrage [1] = 1;
                }
            }                             //sout für mittleren Weg

            switch (rechterWeg) {
                case 0 -> {
                    System.out.println("rechts " + sperreSpruch);
                    befehlsabfrage [2] = 0;
                }
                case 1 -> {
                    System.out.println("Rechts geht es in einen düsteren Wald");
                    befehlsabfrage [2] = 1;
                }
                case 2 -> {
                    System.out.println("Rechts geht es auf eine Wiese");
                    befehlsabfrage [2] = 1;
                }
                case 3 -> {
                    System.out.println("Rechts geht es in eine karge Wüste");
                    befehlsabfrage [2] = 1;
                }
                case 4 -> {
                    System.out.println("Rechts geht es in eine herrliche Oase");
                    befehlsabfrage [2] = 1;
                }
                case 5 -> {
                    System.out.println("Rechts geht es in ein kleines Dorf");
                    befehlsabfrage [2] = 1;
                }
                case 6 -> {
                    System.out.println("Der rechte Weg führt dich in eine Stadt");
                    befehlsabfrage [2] = 1;
                }
                case 7 -> {
                    System.out.println("Rechts geht es auf einen Friedhof");
                    befehlsabfrage [2] = 1;
                }
                case 8 -> {
                    System.out.println("Rechts geht es in ein Dungeon!");
                    befehlsabfrage [2] = 1;
                }
                case 9 -> {
                    System.out.println("Rechts geht es auf einen hohen Berg");
                    befehlsabfrage [2] = 1;
                }
            }                               //sout für rechten Weg


            //Truhen, Händler, Pflanzen generieren:
            int truhe = 0;
            int pferd = 0;
            int haendler = 0;
            int essbarePflanze = 0;
            int heilpflanze = 0;
            int giftpflanze = 0;

            switch (aktuellerRaum1) {
                case 1 -> {
                    if ((int) (Math.random() * 100) < 20)
                        truhe = 1;
                    else
                        truhe = 0;
                    if ((int) (Math.random() * 100) < 20)
                        haendler = 1;
                    else
                        haendler = 0;
                    if ((int) (Math.random() * 100) < 20)
                        essbarePflanze = 1;
                    else
                        essbarePflanze = 0;
                    if ((int) (Math.random() * 100) < 20)
                        heilpflanze = 1;
                    else
                        heilpflanze = 0;
                    if ((int) (Math.random() * 100) < 20)
                        giftpflanze = 1;
                    else
                        giftpflanze = 0;
                    break;
                }                       //Wald
                case 2 -> {
                    if ((int) (Math.random() * 100) < 5)
                        haendler = 1;
                    else
                        haendler = 0;
                    if ((int) (Math.random() * 100) < 35)
                        pferd = 1;
                    else
                        pferd = 0;
                    if ((int) (Math.random() * 100) < 20)
                        essbarePflanze = 1;
                    else
                        essbarePflanze = 0;
                    if ((int) (Math.random() * 100) < 20)
                        heilpflanze = 1;
                    else
                        heilpflanze = 0;
                    if ((int) (Math.random() * 100) < 20)
                        giftpflanze = 1;
                    else
                        giftpflanze = 0;
                    break;
                }                       //Wiese
                case 3 -> {
                    if ((int) (Math.random() * 100) < 35)
                        truhe = 1;
                    else
                        truhe = 0;
                    if ((int) (Math.random() * 100) < 15)
                        haendler = 1;
                    else
                        haendler = 0;
                    if ((int) (Math.random() * 100) < 15)
                        pferd = 1;
                    else
                        pferd = 0;
                    break;
                }                       //Wüste
                case 4 -> {
                    if ((int) (Math.random() * 100) < 25)
                        truhe = 1;
                    else
                        truhe = 0;
                    if ((int) (Math.random() * 100) < 25)
                        haendler = 1;
                    else
                        haendler = 0;
                    if ((int) (Math.random() * 100) < 25)
                        essbarePflanze = 1;
                    else
                        essbarePflanze = 0;
                    if ((int) (Math.random() * 100) < 25)
                        heilpflanze = 1;
                    else
                        heilpflanze = 0;
                    break;
                }                       //Oase
                case 5 -> {
                    if ((int) (Math.random() * 100) < 20)
                        truhe = 1;
                    else
                        truhe = 0;
                    if ((int) (Math.random() * 100) < 50)
                        haendler = 1;
                    else
                        haendler = 0;
                    if ((int) (Math.random() * 100) < 15)
                        essbarePflanze = 1;
                    else
                        essbarePflanze = 0;
                    if ((int) (Math.random() * 100) < 15)
                        heilpflanze = 1;
                    else
                        heilpflanze = 0;
                    break;
                }                       //Dorf
                case 6 -> {
                    if ((int) (Math.random() * 100) < 35)
                        truhe = 1;
                    else
                        truhe = 0;
                    if ((int) (Math.random() * 100) < 65)
                        haendler = 1;
                    else
                        haendler = 0;
                    break;
                }                       //Stadt
                case 7 -> {
                    if ((int) (Math.random() * 100) < 25)
                        truhe = 1;
                    else
                        truhe = 0;
                    if ((int) (Math.random() * 100) < 25)
                        essbarePflanze = 1;
                    else
                        essbarePflanze = 0;
                    if ((int) (Math.random() * 100) < 25)
                        heilpflanze = 1;
                    else
                        heilpflanze = 0;
                    if ((int) (Math.random() * 100) < 25)
                        giftpflanze = 1;
                    else
                        giftpflanze = 0;
                    break;
                }                       //Friedhof
                case 8 -> {
                    if ((int) (Math.random() * 100) < 70)
                        truhe = 1;
                    else
                        truhe = 0;
                    if ((int) (Math.random() * 100) < 10)
                        essbarePflanze = 1;
                    else
                        essbarePflanze = 0;
                    if ((int) (Math.random() * 100) < 10)
                        heilpflanze = 1;
                    else
                        heilpflanze = 0;
                    if ((int) (Math.random() * 100) < 10)
                        giftpflanze = 1;
                    else
                        giftpflanze = 0;
                    break;
                }                       //Dungeon
                case 9 -> {
                    if ((int) (Math.random() * 100) < 10)
                        truhe = 1;
                    else
                        truhe = 0;
                    if ((int) (Math.random() * 100) < 20)
                        haendler = 1;
                    else
                        haendler = 0;
                    if ((int) (Math.random() * 100) < 30)
                        essbarePflanze = 1;
                    else
                        essbarePflanze = 0;
                    if ((int) (Math.random() * 100) < 30)
                        heilpflanze = 1;
                    else
                        heilpflanze = 0;
                    if ((int) (Math.random() * 100) < 10)
                        giftpflanze = 1;
                    else
                        giftpflanze = 0;
                    break;
                }                       //Berg
            }

            String truheString;
            String pferdString;
            String haendlerString;
            String essbarePflanzeString;
            String heilpflanzeString;
            String giftpflanzeString;
            int keinItemSpawn = 0;

            if(truhe == 1) {
                truheString = "eine Truhe";
                befehlsabfrage[3] = 1;
            }else {
                truheString = "";
                befehlsabfrage[3] = 0;
            }
            if(pferd == 1) {
                pferdString = "ein Pferd";
                befehlsabfrage [4] = 1;
            }else {
                pferdString = "";
                befehlsabfrage[4] = 0;
            }
            if(haendler == 1) {
                haendlerString = "einen Händler";
                befehlsabfrage [5] = 1;
            }else{
                haendlerString = "";
                befehlsabfrage[5] = 0;
            }
            if (essbarePflanze == 1) {
                essbarePflanzeString = "Kirschen";
                befehlsabfrage [6] = 1;
            }else {
                essbarePflanzeString = "";
                befehlsabfrage[6] = 0;
            }
            if(heilpflanze == 1) {
                heilpflanzeString = "eine Heilpflanze";
                befehlsabfrage[7] = 1;
            }else {
                heilpflanzeString = "";
                befehlsabfrage[7] = 0;
            }
            if(giftpflanze == 1) {
                giftpflanzeString = "eine Tollkirsche";
                befehlsabfrage[8] = 1;
            }else {
                giftpflanzeString = "";
                keinItemSpawn = 1;
                befehlsabfrage[8] = 0;
            }

            if (keinItemSpawn == 0)
            System.out.println("Hier gibt es " + truheString + ", " + pferdString + ", " + haendlerString + ", " + essbarePflanzeString + ", " + heilpflanzeString + " und " + giftpflanzeString);


            //Gegner generieren:

            int skelett = 0;
            int wolf = 0;
            int riese = 0;
            int ork = 0;
            int banditen = 0;
            int gegnerzahl = (int)((Math.random() * 10) / 2);
            int wahrscheinlichkeitGegner = (int) (Math.random() * 100);
            if(wahrscheinlichkeitGegner < 35)
                gegnerzahl = 0;
            if(gegnerzahl > 0)
                befehlsabfrage [9] = 1;
            else
                befehlsabfrage [9] = 0;

            switch (aktuellerRaum1) {
                case 1 -> {                     //Wald
                    wolf = gegnerzahl;
                    banditen = gegnerzahl;
                }
                case 2 -> {
                    wolf = gegnerzahl / 2;
                    banditen = gegnerzahl;
                    ork = gegnerzahl;
                }
                case 3 -> {
                    skelett = gegnerzahl;
                    wolf = gegnerzahl;
                    banditen = gegnerzahl;
                } case 4 -> {
                    banditen = gegnerzahl;
                    ork = gegnerzahl;
                }
                case 5 -> banditen = gegnerzahl;
                case 6 -> banditen = gegnerzahl / 2;
                case 7 -> skelett = gegnerzahl;
                case 8 -> {
                    skelett = gegnerzahl;
                    wolf = gegnerzahl;
                }
                case 9 -> {
                    riese = gegnerzahl;
                    wolf = gegnerzahl;
                }
            }

            String wolfAnzahl;
            String banditenAnzahl;
            String skeletteAnzahl;
            String riesenAnzahl;
            String orkAnzahl;
            int keinGegnerSpawn = 0;

            if(wolf > 1)
                wolfAnzahl = (gegnerzahl + " Wölfe");
            else {
                wolfAnzahl = "";
                keinGegnerSpawn = 1;
            }
            if(banditen > 1)
                banditenAnzahl = gegnerzahl + " Banditen";
            else{
                banditenAnzahl = "";
            keinGegnerSpawn = 1;}
            if(skelett > 1)
                skeletteAnzahl = gegnerzahl + " Skelette";
            else {
                skeletteAnzahl = "";
                keinGegnerSpawn = 1;
            }
            if(riese > 1)
                riesenAnzahl = gegnerzahl + " Riesen";
            else {
                riesenAnzahl = "";
                keinGegnerSpawn = 1;
            }
            if(ork > 1)
                orkAnzahl = gegnerzahl + " Orks";
            else{
                orkAnzahl = "";
                keinGegnerSpawn = 1;}

            if (keinGegnerSpawn == 0)
            System.out.println("Hier gibt es " + wolfAnzahl + " " + banditenAnzahl + " " + skeletteAnzahl + " " + riesenAnzahl + " " + orkAnzahl);



            //Befehlseingabe:

            System.out.println("Was möchtest du tun? Gib einen der folgenden Befehle ein:");

            String befehlsabfrageLinks = "";
            String befehlsabfrageMitte = "";
            String befehlsabfrageRechts = "";
            String befehlsabfrageTruhe = "";
            String befehlsabfragePferd = "";
            String befehlsabfrageHandel = "";
            String befehlsabfrageHeilpflanze = "";
            String befehlsabfrageEssbarepflanze = "";
            String befehlsabfrageGiftpflanze = "";
            String befehlsabfrageGegner = "";

            if (befehlsabfrage [0] == 1)
                befehlsabfrageLinks = "Nach links gehen";
            else
                befehlsabfrageLinks = "";
            if (befehlsabfrage [1] == 1)
                befehlsabfrageMitte = "Gerade aus gehen";
            else
                befehlsabfrageMitte = "";
            if (befehlsabfrage [2] == 1)
                befehlsabfrageRechts = "Nach rechts gehen";
            else
                befehlsabfrageRechts = "";
            if (befehlsabfrage [3] == 1)
                befehlsabfrageTruhe = "Truhe öffnen";
            else
                befehlsabfrageTruhe = "";
            if (befehlsabfrage [4] == 1)
                befehlsabfragePferd = "Pferd zähmen";
            else
                befehlsabfragePferd = "";
            if (befehlsabfrage [5] == 1)
                befehlsabfrageHandel = "Handeln";
            else
                befehlsabfrageHandel = "";
            if (befehlsabfrage [6] == 1)
                befehlsabfrageHeilpflanze = "Heilpflanze pflücken";
            else
                befehlsabfrageHeilpflanze = "";
            if (befehlsabfrage [7] == 1)
                befehlsabfrageEssbarepflanze = "Kirschen pflücken";
            else
                befehlsabfrageEssbarepflanze = "";
            if (befehlsabfrage [8] == 1)
                befehlsabfrageGiftpflanze = "Tollkirsche pflücken";
            else
                befehlsabfrageGiftpflanze = "";
            if (befehlsabfrage [9] == 1)
                befehlsabfrageGegner = "Gegner Angreifen";
            else
                befehlsabfrageGegner = "";

            System.out.println(befehlsabfrageLinks + " " + befehlsabfrageMitte + " " + befehlsabfrageRechts + " " + befehlsabfragePferd + " " + befehlsabfrageHandel + " " + befehlsabfrageTruhe + " " + befehlsabfrageGiftpflanze + " " + befehlsabfrageEssbarepflanze + " " + befehlsabfrageHeilpflanze + " " + befehlsabfrageGegner);
            System.out.println("Oder tippe 'hilfe' ein, um weitere Befehele gelistet zu bekommen");

            Befehlseingabe.befehlseingabe();

            //Speichern

            //Starte Befehlseingabe

            //sout was passiert ist

            //sout"Wohin gehst du?"


        }
        //While LOOOOOP Ende



    }

}