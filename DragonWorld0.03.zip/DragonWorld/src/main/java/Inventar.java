public class Inventar {

    public static int waffen(int waffentyp) {                                     //Waffenliste

        int aktuellerwaffentyp = 0;
        aktuellerwaffentyp = waffentyp;
        int faust;
        int henkerschwert;
        int grossschwert;
        int morgenstern;
        int kampfhammer;
//        int recurvebogen;
//        int langbogen;
        int waffenstaerke = 0;

        switch (aktuellerwaffentyp) {

            case 0:                                                             //Fäuste
                waffenstaerke = 001005;
                break;

            case 1:                                                             //Henkerschwert
                waffenstaerke = 251015;
                break;

            case 2:                                                             //Großschwert
                waffenstaerke = 501025;
                break;

            case 3:                                                             //Morgenstern
                waffenstaerke = 052515;
                break;

            case 4:                                                             //Kampfhammer
                waffenstaerke = 055025;
                break;

//            case 5:                                                             //Recurvebogen
//
//                break;
//
//            case 6:                                                             //Langbogen
//
//                break;

            default:                                                              //default = Fäuste
                aktuellerwaffentyp = 0;
                break;

        }                                       //00(Schneiden)00(Zertrümmern)00(Blocken)

        return waffenstaerke;

    }                       //Definieren der verschiedenen Waffentypen

    public static int inventary(int position){

        //Waffen:
        int henkerschwert = 0;
        int grossschwert = 0;
        int morgenstern = 0;
        int kampfhammer = 0;

        //Pflanzen
        int kirschen = 0;
        int tollkirschen = 0;
        int heilpflanzen = 0;

        //Geld:
        int geld = 0;

        int [] inventary = {henkerschwert, grossschwert, morgenstern, kampfhammer, kirschen, tollkirschen, heilpflanzen, geld};

        return inventary [position];

    }

}